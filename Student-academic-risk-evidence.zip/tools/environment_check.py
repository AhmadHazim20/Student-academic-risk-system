from pathlib import Path
import json
import platform
import sys

ROOT = Path(__file__).resolve().parents[1]

evidence = {
    "python_version": sys.version,
    "platform": platform.platform(),
    "implementation": platform.python_implementation(),
    "repository_root": str(ROOT),
    "standard_library_only": True,
}

output = ROOT / "environment_evidence.json"
output.write_text(json.dumps(evidence, indent=2))

print(json.dumps(evidence, indent=2))
